# include <iostream>
using namespace std;
int main()
{
	string str;
	cout<<"enter String "<<endl;
	cin>>str; 
	for(char i='a';i<='z'; i++)
    {
    	for ( char j=0 ;j<str.length();j++)
    	{
    		if(str[j]==i)	
			{
				cout<<i;
			}																																								
		}
	}
		for(char i='A';i<='Z'; i++)
    {
    	for ( char j=0 ;j<str.length();j++)
    	{
    		if(str[j]==i)	
			{
				cout<<i;
			}																																							
		}		
	}
     	for(char i='0';i<='8';i=i+2)
    {
    	for ( int j=0 ;j<str.length();j++)
    	{
			if( str[j]==i)	
			{
				cout<<i;
			}																																								
	}
     }
     
	for(char i='1';i<='9'; i=i+2)
    {
    	for ( int j=0 ;j<str.length();j++)
    	{
    		if(str[j]==i)	
			{
				cout<<i;
			}																																								
		}
     }
return 0;
system("pause");
}

